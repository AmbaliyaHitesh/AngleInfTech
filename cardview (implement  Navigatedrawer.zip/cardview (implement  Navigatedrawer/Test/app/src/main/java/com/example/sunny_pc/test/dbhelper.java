package com.example.sunny_pc.test;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;

public class dbhelper extends SQLiteOpenHelper {

    private static String CREATE_TABLE;

    //    Database name
    static String DATABASE_NAME = "EmployeeRecords";

    //    Talble name
    public static final String EMP_NAME = "employee";

    //      Fields for table
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String EMAIL = "email";
    public static final String MOBILENO = "mobileno";
    public static final String PASSWORD = "password";
    public static final String IMAGE = "image";
    public static final String GENDER = "gender";
    public static final String COURSE= "course";

    //      Required resorces to manage database
    private ContentValues CV;
    private SQLiteDatabase dataBase = null;
    private Cursor cursor;

    public dbhelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        CREATE_TABLE = "CREATE TABLE " + EMP_NAME + " (" +
                ID + " INTEGER PRIMARY KEY autoincrement, " +
                NAME + " TEXT, " +
                EMAIL + " TEXT, " +
                MOBILENO + " TEXT, " +
                PASSWORD + " TEXT, " +
                IMAGE + " BLOB, " +
                GENDER + " TEXT, " +
                COURSE + " TEXT)";

        db.execSQL(CREATE_TABLE);
        System.out.println("Table is created...........................!");
    }



    public static Bitmap getPhoto(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        onCreate(db);
    }

    public void addStudent(String name, String email, String mobileno, String password,
    byte[] imagebyte,String gender,String course) {


        dataBase = getWritableDatabase();

        CV = new ContentValues();
        CV.put(NAME, name);
        CV.put(EMAIL, email);
        CV.put(MOBILENO, mobileno);
        CV.put(PASSWORD, password);
        CV.put(IMAGE, imagebyte);
        CV.put(GENDER, gender);
        CV.put(COURSE, course);

        // insert data into database
        dataBase.insert(EMP_NAME, null, CV);
        dataBase.close();
        Log.e("data ", "inserted");

    }
    public String getSinlgeEntry(String email) {
        dataBase = getWritableDatabase();

        Cursor cursor = dataBase.query(EMP_NAME, null, EMAIL + "  = ? ",
                new String[]{email}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return "NOT EXIST";
        }
        cursor.moveToFirst();
        String password = cursor.getString(cursor.getColumnIndex(PASSWORD));
        cursor.close();
        return password;
    }


    public Bitmap getImage(String email) {
        dataBase = getWritableDatabase();

        Cursor cursor = dataBase.query(EMP_NAME, null, EMAIL + "  = ? ",
                new String[]{email}, null, null, null);
        if (cursor.getCount() < 1) // UserName Not Exist
        {
            cursor.close();
            return null;
        }
        cursor.moveToFirst();
        byte[] image = cursor.getBlob(cursor.getColumnIndex(IMAGE));
        ByteArrayInputStream inputStream = new ByteArrayInputStream(image);
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
        cursor.close();
        return bitmap;
    }

    public List<Product> fetchAllData() {

        dataBase = getReadableDatabase();
        Cursor mCursor = dataBase.rawQuery("select * from "+EMP_NAME+"",null);

        List<Product> userList = new ArrayList<>();

        if(mCursor.moveToFirst()){
            do{
                userList.add(new Product(mCursor.getString(mCursor.getColumnIndex("name"))
                        ,mCursor.getString(mCursor.getColumnIndex("email"))
                        ,mCursor.getString(mCursor.getColumnIndex("mobileno"))
                        ,mCursor.getBlob(mCursor.getColumnIndex("image"))));
            }while(mCursor.moveToNext());
        }

        mCursor.close();

        return userList;

    }

    public Boolean checkEmail( String email) {
        dataBase = getWritableDatabase();

        Cursor mCursor = dataBase.query(EMP_NAME, new String[]{EMAIL}, EMAIL + "=" + "'" + email + "'",
                null, null, null, null, null);

        if (mCursor.moveToFirst()) {
            return true;
        }
        return false;
    }
    public void updateRecord(String name, String email, String mobileno, String password,
                             byte[] imagebyte,String gender,String course) {

        dataBase = getWritableDatabase();

        CV = new ContentValues();

        CV.put(NAME, name);
        CV.put(EMAIL, email);
        CV.put(MOBILENO, mobileno);
        CV.put(PASSWORD, password);
        CV.put(IMAGE, imagebyte);
        CV.put(GENDER, gender);
        CV.put(COURSE, course);

//    Update data from database table
        dataBase.update(EMP_NAME, CV,
                null, null);

        dataBase.close();
        Log.e("data ", "update");
    }

    }




