package com.example.sunny_pc.test;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.R.attr.mode;
import static android.R.attr.path;
import static android.R.attr.thicknessRatio;

public class Displaydata extends AppCompatActivity  {

    ListView listView;
    SQLiteDatabase sqLiteDatabase;
    String json_string;    //create string object
    JSONArray jsonArray;    //createjson Array
    dbhelper db;
    RecyclerView recyclerView;
    ProgressBar progressBar;
    Runnable runnable;
    Timer timer;
    Handler handler;
    RecyclerView.LayoutManager linerlayout;
    Cursor c;
    ProductAdpter productAdpter = null;

    private List<Product> product_list = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_displaydata);





       db = new dbhelper(this);
        try {
            product_list = db.fetchAllData();
        } catch (Exception e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show();
        }

        db.close();





        //    listView = (ListView) findViewById(R.id.display_listview);
      /**    String jsonvalue = loadJSONFromAsset();

         try {
         final JSONArray obj = new JSONArray(jsonvalue);

         for (int i = 0; i < obj.length(); ++i) {
         JSONObject person = obj.getJSONObject(i);
         Product p=new Product();
         p.setName(person.getString("name"));
         p.setEmail(person.getString("email"));
         p.setMobileno(person.getString("mobile"));
         product_list.add(p);

         }





         } catch (JSONException e) {
         e.printStackTrace();
         }*/


        progressBar=(ProgressBar)findViewById(R.id.pro);

        progressBar.setVisibility(View.VISIBLE);
        handler=new Handler();
        runnable=new Runnable() {
            @Override
            public void run() {
                progressBar.setVisibility(View.GONE);

            }
        };
        timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {

                handler.post(runnable);
            }
        },1000,1000);


        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.item_animation_fall_down);
        recyclerView.setAnimation(anim);
        anim.start();
        linerlayout = new LinearLayoutManager(this);
        productAdpter = new ProductAdpter(product_list);
        recyclerView.setLayoutManager(linerlayout);
        recyclerView.setAdapter(productAdpter); //  final JSONArray geodata = obj.getJSONArray("");


      /**   productAdpter = new ProductAdpter(this, R.layout.activity_display_product_row, product_list);
         listView.setAdapter(productAdpter);*/

    }




    /**   public String loadJSONFromAsset() {
     String json = null;
     try {
     InputStream is = getAssets().open("hitseh.json");
     int size = is.available();
     byte[] buffer = new byte[size];
     is.read(buffer);
     is.close();
     json = new String(buffer, "UTF-8");
     } catch (IOException ex) {
     ex.printStackTrace();
     return null;
     }
     return json;
     }*/

}