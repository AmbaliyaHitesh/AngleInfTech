package com.example.sunny_pc.test;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputValidation;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.R.attr.path;

public class Registration extends AppCompatActivity implements CompoundButton.OnCheckedChangeListener {

    ImageView image;
    EditText edName, edEmail, edMobileno, edPassword, edConformpassword;
    Button btnSignup;
    TextView textViewLogin;
    CheckBox chkmscit, chkbca;
    RadioButton rdmale, rdfmale;
    RadioGroup rg;
    Context context;
    private ObjectInputValidation inputValidation;
    private static final int SELECT_PICTURE = 100;
    private static final String TAG = "SignUp";
    public static final String Email = "emailKey";
    public static final String Name = "emailKey";
    public static final String Mobileno = "emailKey";
    public static final String Password = "emailKey";
    public static final String Conformpassword = "emailKey";
    private dbhelper db;
    private Cursor cursor;
    String gender;
    String Course;
    ContentValues cv;
    private byte[] imageByte;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        image = (ImageView) findViewById(R.id.imageView);
        edName = (EditText) findViewById(R.id.txt_name);
        edEmail = (EditText) findViewById(R.id.txt_email);
        edMobileno = (EditText) findViewById(R.id.txt_mobileno);
        edPassword = (EditText) findViewById(R.id.txt_password);
        edConformpassword = (EditText) findViewById(R.id.txt_conformpassword);
        btnSignup = (Button) findViewById(R.id.btn_signup);
        chkmscit = (CheckBox) findViewById(R.id.checkBox_mscit);
        chkmscit.setOnCheckedChangeListener(this);
        chkbca = (CheckBox) findViewById(R.id.checkBox_bca);
        chkbca.setOnCheckedChangeListener(this);
        rg = (RadioGroup) findViewById(R.id.radioGroup);
        textViewLogin = (TextView) findViewById(R.id.textView_login);
        rdmale = (RadioButton) findViewById(R.id.radio_male);
        rdfmale = (RadioButton) findViewById(R.id.radio_female);
        cv=new ContentValues();
        db = new dbhelper(this);
        edEmail.setText("");
        edName.setText("hitesh");
        edMobileno.setText("9909397416");
        edPassword.setText("1234567");
        edConformpassword.setText("1234567");
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImageChooser();
            }
        });


        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (edName.getText().toString().length() == 0) {
                    edName.setError("First name not entered");
                    edName.requestFocus();

                } else if (!isValidEmail(edEmail.getText().toString())) {
                    String getText = edEmail.getText().toString();
                    edEmail.setError("Email not entered");
                    edEmail.requestFocus();

                } else if (!isValidMobileNo(edMobileno.getText().toString())) {

                    String getText = edMobileno.getText().toString();
                    edMobileno.setError("MobileNo not entered");
                    edMobileno.requestFocus();

                } else if (!isValidPassword(edPassword.getText().toString())) {


                    String getText = edPassword.getText().toString();
                    edPassword.setError("password not entered");
                    edPassword.requestFocus();

                } else if (!isValidConformPassword(edConformpassword.getText().toString())) {
                    String getText = edConformpassword.getText().toString();
                    edConformpassword.setError("ConformPassword not entered");
                    edConformpassword.requestFocus();
                }

                else if(db.checkEmail(edEmail.getText().toString())) {
                    Toast.makeText(getApplicationContext(),"Email Address Allrady define",Toast.LENGTH_SHORT).show();
                }
                else {
                    if(imageByte != null) {
                        db.addStudent(edName.getText().toString(), edEmail.getText().toString(),
                                edMobileno.getText().toString(), edPassword.getText().toString(),
                                imageByte, gender, Course);

                        Toast.makeText(Registration.this, "Data SuccessFully Insert", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        textViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), Login.class);
                startActivity(i);
            }
        });
    }


    // convert from bitmap to byte array
    public static byte[] getBytes(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteBuffer = new ByteArrayOutputStream();
        int bufferSize = 1024;
        byte[] buffer = new byte[bufferSize];

        int len = 0;
        while ((len = inputStream.read(buffer)) != -1) {
            byteBuffer.write(buffer, 0, len);
        }
        return byteBuffer.toByteArray();
    }
    // validating email id
    private boolean isValidEmail(String email) {
        if (email != null) {
            Pattern pattern;
            Matcher matcher;
            final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)";
            pattern = Pattern.compile(EMAIL_PATTERN);
            matcher = pattern.matcher(email);
            return matcher.matches();
        }
        return false;
    }

    private boolean isValidMobileNo(String mobileno) {
        String MOBILENO_PATTERN = "[0-9]{1,10}";
        Pattern pattern = Pattern.compile(MOBILENO_PATTERN);
        Matcher matcher = pattern.matcher(mobileno);
        return matcher.matches();
    }

    private boolean isValidPassword(String pass) {
        if (pass != null && pass.length() > 6) {
            return true;
        }
        return false;
    }

    private boolean isValidConformPassword(String pass) {
        if (pass != null && pass.length() > 6) {
            return true;
        }
        return false;
    }

    void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_PICTURE);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            if (requestCode == SELECT_PICTURE) {
                // Get the url from data
                if(data != null) {
                    Uri selectedImageUri = data.getData();
                    if(null != selectedImageUri){
                        Log.i(TAG, "Image Path : " + path);

                        image.setImageURI(selectedImageUri);

                        try {
                            InputStream iStream = getContentResolver().openInputStream(selectedImageUri);
                            imageByte = getBytes(iStream);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

    public void RadioButtonClicked(View view) {
//This variable will store whether the user was male or female
// Check that the button is  now checked?
        boolean checked = ((RadioButton) view).isChecked();
// Check which radio button was clicked
        switch (view.getId()) {
            case R.id.radio_female:
                if (checked)
                    gender = "female";
                break;
            case R.id.radio_male:
                if (checked)
                    gender = "male";
                break;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.checkBox_mscit:
                if (isChecked)
                    Course = "mscit";
                break;
            case R.id.checkBox_bca:
                if (isChecked)
                    Course = "bca";
                break;

        }

    }



}
