package com.example.sunny_pc.test;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ProductAdpter extends RecyclerView.Adapter<ProductAdpter.ViewHolder> {

    Context context;
    private List<Product> productList = new ArrayList<>();

    public ProductAdpter(List<Product> productList) {

        this.productList = productList;
    }

    @Override
    public ProductAdpter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.album_card, parent, false);


        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ProductAdpter.ViewHolder holder, int position) {

        Product product = productList.get(position);
        holder.name.setText(product.getName().toString());
        holder.email.setText(product.getEmail().toString());
        holder.mobileno.setText(product.getMobileno().toString());
        holder.imageView.setImageBitmap(getImage(product.getImg()));


    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView name, email, mobileno;
        ImageView imageView;


        public ViewHolder(View itemView) {
            super(itemView);
            name = (TextView) itemView.findViewById(R.id.name);
            email = (TextView) itemView.findViewById(R.id.email);
            mobileno = (TextView) itemView.findViewById(R.id.mobileno);
           imageView=(ImageView)itemView.findViewById(R.id.thumbnail);



        }


    }


/**
 private List<Product> productList = new ArrayList<>();



 public ProductAdpter(@NonNull Context context, int resource,List<Product> productList) {
 super(context, resource,productList);
 this.productList = productList;
 }

 public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

 if (convertView == null) {
 LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
 convertView = layoutInflater.inflate(R.layout.activity_display_product_row, null);
 }

 TextView name = (TextView) convertView.findViewById(R.id.name);
 TextView email = (TextView) convertView.findViewById(R.id.email);
 TextView mobile = (TextView) convertView.findViewById(R.id.mobileno);
 ImageView imageView=(ImageView)convertView.findViewById(R.id.thumbnail);

 Product product = productList.get(position);
 name.setText(product.getName().toString());
 email.setText(product.getEmail().toString());
 mobile.setText(product.getMobileno().toString());

 //imageView.setImageBitmap(getImage(product.getImg()));

 return convertView;
 }
 public static Bitmap getImage(byte[] image) {
 return BitmapFactory.decodeByteArray(image, 0, image.length);
 }
 */
public static Bitmap getImage(byte[] image) {
    return BitmapFactory.decodeByteArray(image, 0, image.length);
}
}
