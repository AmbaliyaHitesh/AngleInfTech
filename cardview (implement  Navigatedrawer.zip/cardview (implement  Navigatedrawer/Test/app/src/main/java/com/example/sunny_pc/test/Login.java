package com.example.sunny_pc.test;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {

    EditText edEmail, edPassword;
    Button btnLogin;
    TextView tv_SignUp;
    dbhelper db;
    public static final String Email = "emailKey";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        db = new dbhelper(this);

        edEmail = (EditText) findViewById(R.id.txt_email);
        edPassword = (EditText) findViewById(R.id.txt_password);
        btnLogin = (Button) findViewById(R.id.btn_Login);


        // edEmail.setText("hiteshambaliya95@gmail.com");
        edPassword.setText("1234567");

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String email = edEmail.getText().toString();
                String password = edPassword.getText().toString();
                String storedPassword = db.getSinlgeEntry(email);
                if (password.equals(storedPassword)) {
                    Toast.makeText(Login.this, "Congrats: Login Successfull", Toast.LENGTH_LONG).show();
                    Intent main = new Intent(getApplicationContext(), Displaydata.class);

                    startActivity(main);

                    SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(Login.this);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(Email, email);
                    editor.commit();


                } else {
                    Toast.makeText(Login.this,
                            "email or Password does not match",
                            Toast.LENGTH_LONG).show();

                }


            }
        });



        }
    private boolean isValidEmail(String email) {
        if (email != null) {
            Pattern pattern;
            Matcher matcher;
            final String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)";
            pattern = Pattern.compile(EMAIL_PATTERN);
            matcher = pattern.matcher(email);
            return matcher.matches();
        }
        return false;
    }

    private boolean isValidPassword(String pass) {
        if (pass != null && pass.length() > 6) {
            return true;
        }
        return false;
    }


    }
