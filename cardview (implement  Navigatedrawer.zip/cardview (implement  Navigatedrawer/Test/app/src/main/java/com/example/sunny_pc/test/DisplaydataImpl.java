package com.example.sunny_pc.test;

class DisplaydataImpl extends Displaydata {
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
